#!/usr/bin/env python
# -*- coding:utf-8 -*-
import os
import random
import numpy as np
import torch
from scipy import ndimage
from scipy.ndimage.interpolation import zoom
from torch.utils.data import Dataset
import h5py
from torchvision import transforms

def random_rot_flip(image, label):
    """
    随机翻转
    Crop randomly flip the dataset in a sample
    Args:
    output_size (int): Desired output size
    """
    k = np.random.randint(0, 4)    # 生成一个在0-4之间的整数（包括low,不包括high）
    image = np.rot90(image, k)      # 随机旋转90度 * k
    label = np.rot90(label, k)
    axis = np.random.randint(0, 2)  # 随机选择一个轴
    image = np.flip(image, axis=axis).copy()  # axis=0：上下翻转，行不变， axis=1：左右翻转，列不变
    label = np.flip(label, axis=axis).copy()
    
    return image, label


def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label


class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):  # 定义了这个方法后，表示RandomGenerator这个类实例化后就可以和函数一样使用了
        image, label = sample['image'], sample['label']
        #if random.random() > 0.5:
        #    image, label = random_rot_flip(image, label)
        #elif random.random() > 0.5:
        #    image, label = random_rotate(image, label)
        if random.random() > 0.5:
            transform2 = transforms.Compose([transforms.RandomHorizontalFlip(p=1),])
            image = transform2(image)
        elif random.random() > 0.5:
            transform2 = transforms.Compose([transforms.RandomRotation(20),])
            image = transform2(image)
        x, y, z = image.shape
        image = image.permute(2, 0, 1).unsqueeze(0)
        label = label.permute(2, 0, 1).unsqueeze(0)
        
        if x != self.output_size[0] or y != self.output_size[1]:
            image = torch.nn.functional.interpolate(image, size = (224,224))
            label = torch.nn.functional.interpolate(label, size = (224,224))
        
        image = torch.squeeze(torch.mean(image, dim=1, keepdim=True), dim = 1)
        label = multi_2_single(label).squeeze(0)
        sample = {'image': image, 'label': label.long()}
        return sample


class BraTS_dataset(Dataset):
    def __init__(self, base_dir, list_dir, split, transform=None):
        self.transform = transform  # using transform in torch!
        self.split = split
        self.sample_list = open(os.path.join(list_dir, self.split+'.txt')).readlines()
        self.data_dir = base_dir

    def __len__(self):
        return len(self.sample_list)

    def __getitem__(self, idx):     # 让对象实现迭代功能
        if self.split == "train" or self.split == "valid":
            slice_name = self.sample_list[idx].strip('\n')
            data_path = os.path.join(self.data_dir, self.split, slice_name)  #####
            h5f = h5py.File(data_path, 'r')
            image, label = h5f['image'][:], h5f['mask'][:]
        else:
            vol_name = self.sample_list[idx].strip('\n')
            filepath = self.data_dir + "/{}".format(vol_name)
            #print("vol_name ==== ", filepath)
            #filepath = '/home/stu1/wj/vig_sc_version03/data/BraTS/test/volume_194_slice_91.h5'
            #filepath = '/home/stu1/wj/vig_sc_version03/data/BraTS/test/volume_194_slice_81.h5'
            h5f = h5py.File(filepath, 'r')
            image, label = h5f['image'][:], h5f['mask'][:]
        image = torch.from_numpy(image.astype(np.float32))
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label}
        #sample = {'image': torch.from_numpy(image), 'label': torch.from_numpy(label)}
        if self.transform and self.split == "train":
            sample = self.transform(sample)
        sample['case_name'] = self.sample_list[idx].strip('\n')
        #from IPython import embed; embed()
        #exit()
        return sample

def multi_2_single(raw_label):
    _, C, _, _ = raw_label.shape
    for idx in range(C):
        raw_label[:, idx, ...] = torch.where(raw_label[:, idx, ...] > 0, idx + 1, 0)
    return torch.sum(raw_label, dim=1)

